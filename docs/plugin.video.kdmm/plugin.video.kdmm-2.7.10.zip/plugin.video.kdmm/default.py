"""
KDMM – default.py
Plugin entry point.

Called by TMDb Bingie Helper when the user presses Play or Resume.
Runs as a standard Kodi resolver plugin: always exits via
xbmcplugin.setResolvedUrl() so Kodi manages playback internally and
all Player-subclass callbacks (onAVStarted, onPlayBackStopped, …) fire
correctly in service.py.

Flow:
  1. Parse media ID from URL params (IMDB ID + optional season/episode).
  2. Look up a cached stream URL.  On cache miss, look up torrent hashes
     (Torrentio, plus DMM with a sponsor key), check debrid availability, resolve best, and save to cache.
  3. Read locally-stored resume position (populated by service.py).
  4. Set window properties so the background service can apply the resume seek
     after A/V playback has actually started (onAVStarted).
  5. Resolve to Kodi via xbmcplugin.setResolvedUrl().
"""

import json
import os
import sys
import threading
import time
from urllib.parse import parse_qsl, urlencode, urlsplit

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# ------------------------------------------------------------------ #
# Bootstrap: add lib/ to sys.path before importing local modules.
# ------------------------------------------------------------------ #
_ADDON = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo("id")
_ADDON_PATH = _ADDON.getAddonInfo("path")
_USERDATA_PATH = xbmcvfs.translatePath(
    f"special://profile/addon_data/{_ADDON_ID}/"
)
# Plugin handle – valid when Kodi invoked us as a resolver.
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
# Kodi 18+ passes "resume:false" as sys.argv[3] when PlayMedia(..., noresume)
# is used (i.e. "Play from Beginning").  Any other value (or absent) means
# the normal resume-from-saved-position behaviour applies.
NO_RESUME = len(sys.argv) > 3 and "resume:false" in sys.argv[3].lower()
sys.path.insert(0, os.path.join(_ADDON_PATH, "lib"))

from cache import (  # noqa: E402 (after sys.path)
    PREWARM_MAX_AGE_SECONDS,
    LastPlayedSource,
    PackBindingCache,
    ProgressCache,
    StreamCache,
    UserBlockedSourceCache,
)
from dmm import (    # noqa: E402
    CachedStreamBlocked,
    CachedStreamUnavailable,
    candidate_matches_episode_identity,
    candidate_matches_audio_preference,
    cleanup_stream_candidate,
    fetch_all_cached_streams,
    is_av1_stream,
    is_stream_accessible,
    refresh_cached_stream,
)
from playback import apply_playback_metadata, build_playback_context, encode_playback_context  # noqa: E402
from ad_auth import authorize as ad_authorize, revoke as ad_revoke  # noqa: E402
from rd_auth import authorize as rd_authorize, revoke as rd_revoke  # noqa: E402
from settings_persistence import get_stream_cache_ttl_hours  # noqa: E402
from user_messages import describe_failure  # noqa: E402

# ------------------------------------------------------------------ #
# Constants – window property keys shared with service.py
# ------------------------------------------------------------------ #
WIN = xbmcgui.Window(10000)
PROP_MEDIA_ID = "kdmm.media_id"
PROP_RESUME_TIME = "kdmm.resume_time"
PROP_CANDIDATES = "kdmm.candidates"   # JSON list of selected stream candidates
PROP_PLAYBACK_CONTEXT = "kdmm.playback_context"
PROP_PENDING_PLAYBACK = "kdmm.pending_playback"


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[KDMM] {msg}", level)


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _build_final_url(url, headers_dict):
    """
    Produce the final URL string for xbmc.Player().play().

    If the stream has proxy headers (e.g. an Authorization bearer token),
    we append them after a pipe in the format that Kodi's HTTP handler
    understands:
        https://example.com/stream.mp4|Authorization=Bearer+abc
    """
    if not headers_dict:
        return url, False

    formatted = urlencode(headers_dict)
    if not formatted:
        return url, False
    return f"{url}|{formatted}", True


def _url_path_lower(url):
    """Return the lowercase stream path without Kodi pipe headers or query."""
    return (url or "").split("|", 1)[0].split("?", 1)[0].lower()


def _url_host(url):
    """Host only: the rest of a debrid link is a credential and stays out of the log."""
    try:
        return urlsplit(url or "").netloc or "stream"
    except Exception:
        return "stream"


def _mimetype_for_url_path(url_path):
    if url_path.endswith(".ts"):
        return "video/mp2t"
    if url_path.endswith(".mpd"):
        return "application/dash+xml"
    if url_path.endswith(".m3u8"):
        return "application/vnd.apple.mpegurl"
    if url_path.endswith(".mkv"):
        return "video/x-matroska"
    if url_path.endswith((".mp4", ".m4v")):
        return "video/mp4"
    if url_path.endswith(".avi"):
        return "video/x-msvideo"
    if url_path.endswith(".webm"):
        return "video/webm"
    return ""


def _should_use_ffmpegdirect(url):
    url_path = _url_path_lower(url)
    adaptive_exts = (".ts", ".mpd", ".m3u8")
    return url_path.endswith(adaptive_exts)


def _play_stream(media_id, url, headers_dict, imdb, tmdb, title, showtitle,
                 season, episode, year=None, no_resume=False):
    """
    Build the ListItem and resolve it to Kodi via setResolvedUrl.
    """
    final_url, has_headers = _build_final_url(url, headers_dict)

    li = xbmcgui.ListItem(path=final_url)
    li.setProperty("IsPlayable", "true")

    playback_context = build_playback_context(
        media_id=media_id,
        imdb=imdb,
        tmdb=tmdb,
        title=title,
        showtitle=showtitle,
        season=season,
        episode=episode,
        year=year,
    )
    apply_playback_metadata(li, playback_context)

    _url_path = _url_path_lower(url)
    if _should_use_ffmpegdirect(url):
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstreamaddon", "inputstream.ffmpegdirect")
        mimetype = _mimetype_for_url_path(_url_path)
        if mimetype:
            li.setMimeType(mimetype)
        try:
            li.setContentLookup(False)
        except Exception:
            pass

    # Tag the item with its IMDB number for Trakt scrobbling.
    if imdb:
        WIN.setProperty("script.trakt.ids", json.dumps({"imdb": imdb}))

    # Tell the service which item is playing so it can save progress later.
    WIN.setProperty(PROP_MEDIA_ID, media_id)
    WIN.setProperty(PROP_PLAYBACK_CONTEXT, encode_playback_context(playback_context))
    WIN.setProperty(PROP_PENDING_PLAYBACK, json.dumps({
        "media_id": media_id,
        "url": url,
        "timestamp": time.time(),
    }))

    # Queue a resume seek via window property; service.py reads it in onAVStarted.
    progress_cache = ProgressCache(_USERDATA_PATH)
    resume_time = progress_cache.get_resume_time(media_id)
    if no_resume:
        _log(f"Play from beginning requested for {media_id} – skipping resume seek")
        WIN.clearProperty(PROP_RESUME_TIME)
    elif resume_time > 5.0:
        _log(f"Queuing resume seek to {resume_time:.1f}s for {media_id}")
        WIN.setProperty(PROP_RESUME_TIME, str(resume_time))
    else:
        WIN.clearProperty(PROP_RESUME_TIME)

    _log(f"Resolving stream to Kodi: {_url_host(url)}")
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)


def _filter_playable_candidates(candidates, season=None, episode=None, episode_title=None):
    if isinstance(candidates, dict):
        candidates = [candidates]
    original = list(candidates or [])
    filtered = [
        candidate for candidate in original
        if not is_av1_stream(candidate)
        and candidate_matches_audio_preference(candidate)
        and candidate_matches_episode_identity(
            candidate,
            season=season,
            episode=episode,
            episode_title=episode_title,
        )
    ]
    av1_removed = sum(1 for candidate in original if is_av1_stream(candidate))
    audio_removed = sum(
        1 for candidate in original
        if not is_av1_stream(candidate)
        and not candidate_matches_audio_preference(candidate)
    )
    identity_removed = len(original) - av1_removed - audio_removed - len(filtered)
    if av1_removed:
        _log(f"Filtered {av1_removed} cached/resolved AV1 candidate(s)", xbmc.LOGWARNING)
    if audio_removed:
        _log(
            f"Filtered {audio_removed} cached/resolved candidate(s) missing "
            "the current audio language probe",
            xbmc.LOGWARNING,
        )
    if identity_removed:
        _log(
            f"Filtered {identity_removed} cached/resolved candidate(s) with "
            "generic or unverified episode identity",
            xbmc.LOGWARNING,
        )
    return filtered


def _candidate_has_probe_consumed_url(candidate):
    return (
        candidate.get("av1_probe") in ("not_av1", "unknown")
        and not candidate.get("url_refreshed_after_probe")
    )


def _candidate_needs_accessibility_check(candidate):
    # The AV1 probe already touched the first debrid URL. When the resolver
    # refreshed it afterward, leave that fresh URL untouched for Kodi.
    return not bool(candidate.get("url_refreshed_after_probe"))


def _cache_needs_refresh(cached):
    candidates = cached if isinstance(cached, list) else [cached]
    return any(_candidate_has_probe_consumed_url(c) for c in candidates if isinstance(c, dict))


def _cache_can_refresh_direct_url(cached):
    candidates = cached if isinstance(cached, list) else [cached]
    return any(
        isinstance(candidate, dict)
        and (
            (candidate.get("provider") == "alldebrid"
             and len((candidate.get("hash") or "")) == 40)
            or (candidate.get("provider") == "realdebrid"
                and bool(candidate.get("rd_link")))
        )
        for candidate in candidates
    )


def _episode_cache_needs_identity_refresh(cached):
    candidates = cached if isinstance(cached, list) else [cached]
    return any(
        isinstance(candidate, dict)
        and candidate.get("episode_identity_probe") not in ("matched", "unknown")
        for candidate in candidates
    )


def _prewarmed_cache_is_stale(stream_cache, media_id, cached):
    """An idle pre-resolve stored this entry and its link may have expired.

    Entries whose link can be rebuilt (AllDebrid by hash, Real-Debrid by its
    stored hoster link) are exempt. This only catches Real-Debrid entries
    saved before hoster links were stored.
    """
    age = stream_cache.prewarm_age(media_id)
    if age is None or age <= PREWARM_MAX_AGE_SECONDS:
        return False
    return not _cache_can_refresh_direct_url(cached)


def _cache_is_user_blocked(cached):
    candidates = cached if isinstance(cached, list) else [cached]
    blocked = UserBlockedSourceCache(_USERDATA_PATH)
    return any(
        isinstance(candidate, dict) and blocked.is_blocked(candidate.get("hash"))
        for candidate in candidates
    )


def _playback_label(title, showtitle, season, episode, year):
    if showtitle and season and episode:
        try:
            return f"{showtitle} S{int(season):02d}E{int(episode):02d}"
        except ValueError:
            return showtitle
    if title and year:
        return f"{title} ({year})"
    return title or showtitle


def _cleanup_candidates(candidates):
    for candidate in candidates or []:
        cleanup_stream_candidate(candidate)


def _provider_state_key(candidate):
    if not isinstance(candidate, dict):
        return None
    provider = candidate.get("provider")
    item_id = candidate.get("provider_item_id") or candidate.get("ad_magnet_id")
    if not provider or not item_id:
        return None
    return provider, str(item_id)


def _authorize_debrid_account():
    choice = xbmcgui.Dialog().select(
        "KDMM - Authorization Required",
        ["Authorize Real-Debrid", "Authorize AllDebrid", "Cancel"],
    )
    if choice == 0:
        return rd_authorize()
    if choice == 1:
        return ad_authorize()
    return False


def _auth_error_notice(error_code):
    code = (error_code or "").strip()
    if code == "no_debrid_token":
        return (
            "Debrid account required",
            "Authorize a debrid account now to continue watching?",
        )
    if code == "all_debrid_tokens_rejected":
        return (
            "Debrid authorization rejected",
            "Re-authorize Real-Debrid or AllDebrid now to continue watching?",
        )
    if "alldebrid" in code and "realdebrid" not in code:
        return (
            "AllDebrid authorization failed",
            "Re-authorize AllDebrid now to continue watching?",
        )
    if "realdebrid" in code and "alldebrid" not in code:
        return (
            "Real-Debrid authorization failed",
            "Re-authorize Real-Debrid now to continue watching?",
        )
    return (
        "Debrid authorization failed",
        "Re-authorize Real-Debrid or AllDebrid now to continue watching?",
    )


def _wait_for_fetch(thread, cancel_event):
    xbmc.executebuiltin("ActivateWindow(busydialog)")
    xbmc.sleep(100)
    started = False
    try:
        while thread.is_alive():
            visible = (
                xbmc.getCondVisibility("Window.IsActive(busydialog)")
                or xbmc.getCondVisibility("Window.IsVisible(busydialog)")
            )
            if visible:
                started = True
            elif started:
                cancel_event.set()
                return False
            xbmc.sleep(200)
        return True
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")


# ------------------------------------------------------------------ #
# Actions
# ------------------------------------------------------------------ #

def action_play(params):
    """
    Core handler for play_movie / play_episode.
    Resolves or re-uses a cached stream URL and starts playback.
    """
    action = params.get("action", "play_movie")
    imdb = params.get("imdb", "").strip()
    tmdb = params.get("tmdb", "").strip()
    season = params.get("season", "").strip()
    episode = params.get("episode", "").strip()
    title = params.get("title", "").strip()
    showtitle = params.get("showtitle", "").strip()
    year = params.get("year", "").strip()
    query_title = showtitle or title
    force_refresh = params.get("refresh", "0") == "1"

    # Determine catalog type and video_id.
    if action == "play_episode" and season and episode:
        catalog_type = "series"
        video_id = f"{imdb}:{season}:{episode}"
        media_id = video_id
    else:
        catalog_type = "movie"
        video_id = imdb
        media_id = imdb

    if not media_id:
        xbmcgui.Dialog().notification(
            "KDMM", "Missing media ID",
            xbmcgui.NOTIFICATION_ERROR,
        )
        return

    ttl_hours = get_stream_cache_ttl_hours(_USERDATA_PATH)
    stream_cache = StreamCache(_USERDATA_PATH, ttl=ttl_hours * 3600)
    pack_cache = PackBindingCache(_USERDATA_PATH)
    bound_pack = pack_cache.get(imdb, season) if catalog_type == "series" else None

    # ---- 1. Try stream cache ---------------------------------------- #
    candidates = None
    if not force_refresh:
        cached = stream_cache.get(media_id)
        if cached and _cache_is_user_blocked(cached):
            _log(f"Refreshing {media_id}; cached source was blocked by the user")
            stream_cache.clear(media_id)
            cached = None
        if cached and _prewarmed_cache_is_stale(stream_cache, media_id, cached):
            _log(f"Refreshing {media_id}; stream found while idle is too old to trust")
            stream_cache.clear(media_id)
            cached = None
        if cached:
            if _cache_needs_refresh(cached):
                if _cache_can_refresh_direct_url(cached):
                    _log(
                        f"Refreshing direct URL for {media_id}; "
                        "cached source identity is still usable"
                    )
                else:
                    _log(f"Refreshing {media_id}; cached URL may have been consumed by codec probe")
                    stream_cache.clear(media_id)
                    cached = None
            elif catalog_type == "series" and _episode_cache_needs_identity_refresh(cached):
                _log(f"Refreshing {media_id}; cached episode stream predates identity checks")
                stream_cache.clear(media_id)
                cached = None
            if cached:
                cached_hash = ""
                if isinstance(cached, list) and cached:
                    cached_hash = (cached[0].get("hash") or "").lower()
                if bound_pack and cached_hash != (bound_pack.get("hash") or "").lower():
                    _log(f"Bypassing stale episode cache for {media_id}; bound pack is {bound_pack.get('hash')}")
                else:
                    _log(f"Cache hit for {media_id}")
                    candidates = _filter_playable_candidates(
                        cached,
                        season=season,
                        episode=episode,
                        episode_title=title,
                    )
                    if not candidates:
                        _log(f"Cached candidates for {media_id} were AV1 only; refreshing")
                        stream_cache.clear(media_id)
                        if catalog_type == "series":
                            pack_cache.clear(imdb, season)
                        candidates = None
                        bound_pack = None
                        cached = None
                    if cached and candidates and _ADDON.getSetting("notify_cache_hit").lower() == "true":
                        xbmcgui.Dialog().notification(
                            "KDMM", "Using cached stream",
                            xbmcgui.NOTIFICATION_INFO, 2000,
                        )
                    if cached and candidates:
                        try:
                            refreshed = refresh_cached_stream(
                                candidates[0],
                                season=season if catalog_type == "series" else None,
                                episode=episode if catalog_type == "series" else None,
                                query_title=query_title,
                                year=year,
                                episode_title=title if catalog_type == "series" else None,
                            )
                            candidates = [refreshed]
                            stream_cache.set(media_id, candidates)
                        except CachedStreamUnavailable as exc:
                            _log(
                                f"Cached stream for {media_id} is gone ({exc}); searching again",
                                xbmc.LOGWARNING,
                            )
                            stream_cache.clear(media_id)
                            if catalog_type == "series":
                                pack_cache.clear(imdb, season)
                            candidates = None
                        except CachedStreamBlocked as exc:
                            _log(
                                f"Cached stream for {media_id} is blocked by AllDebrid: {exc}",
                                xbmc.LOGWARNING,
                            )
                            stream_cache.clear(media_id)
                            if catalog_type == "series":
                                pack_cache.clear(imdb, season)
                            xbmcgui.Dialog().notification(
                                "KDMM",
                                "Cached AllDebrid file is blocked",
                                xbmcgui.NOTIFICATION_ERROR, 8000)
                            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                            return
                        except PermissionError as exc:
                            _log(f"Could not refresh cached stream auth: {exc}", xbmc.LOGWARNING)
                            xbmcgui.Dialog().notification(
                                "KDMM authorization",
                                _auth_error_notice(str(exc))[0],
                                xbmcgui.NOTIFICATION_ERROR, 8000)
                            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                            return
                        except Exception as exc:
                            _log(f"Could not refresh cached stream for {media_id}: {exc}",
                                 xbmc.LOGWARNING)
                            xbmcgui.Dialog().notification(
                                "KDMM playback",
                                describe_failure(exc, "debrid", "refreshing cached stream"),
                                xbmcgui.NOTIFICATION_ERROR, 8000)
                            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                            return

    # ---- 2. Fetch fresh from torrent lookup + debrid if needed ------ #
    if candidates is None:
        _log(f"Cache miss – looking up torrents + debrid for {media_id}")
        if force_refresh and catalog_type == "series":
            pack_cache.clear(imdb, season)

        fetch_result = {}
        cancel_event = threading.Event()

        def _fetch():
            try:
                fetch_result["candidates"] = fetch_all_cached_streams(
                    catalog_type, video_id, cancel_event=cancel_event,
                    query_title=query_title, year=year,
                    userdata_path=_USERDATA_PATH,
                    ignore_pack_binding=force_refresh,
                    episode_title=title if catalog_type == "series" else None)
            except PermissionError as exc:
                fetch_result["needs_auth"] = True
                fetch_result["auth_error"] = str(exc)
            except Exception as exc:
                fetch_result["error"] = exc

        t = threading.Thread(target=_fetch, daemon=True)
        t.start()

        if not _wait_for_fetch(t, cancel_event):
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return

        # Auth token missing or expired — prompt user to authorize a provider (main thread)
        if fetch_result.get("needs_auth"):
            auth_error = fetch_result.get("auth_error") or "no_debrid_token"
            notice, question = _auth_error_notice(auth_error)
            _log(f"Debrid authorization problem ({auth_error}) – prompting user to authorize",
                 xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(
                "KDMM authorization",
                notice,
                xbmcgui.NOTIFICATION_ERROR,
                10000,
            )
            if xbmcgui.Dialog().yesno(
                "KDMM – Authorization Required",
                f"{notice}[CR]{question}",
                yeslabel="Authorize",
                nolabel="Cancel",
            ):
                if _authorize_debrid_account():
                    # Re-run the fetch now that we have a fresh token
                    fetch_result.clear()
                    cancel_event.clear()
                    t2 = threading.Thread(target=_fetch, daemon=True)
                    t2.start()
                    if not _wait_for_fetch(t2, cancel_event):
                        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                        return
                else:
                    xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                    return
            else:
                xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                return
            if fetch_result.get("needs_auth"):
                auth_error = fetch_result.get("auth_error") or "no_debrid_token"
                notice, _question = _auth_error_notice(auth_error)
                xbmcgui.Dialog().notification(
                    "KDMM", notice,
                    xbmcgui.NOTIFICATION_ERROR, 8000)
                xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
                return

        if "error" in fetch_result:
            _log(f"fetch_all_cached_streams raised: {fetch_result['error']}", xbmc.LOGERROR)
            message = describe_failure(fetch_result["error"], "KDMM", "fetching streams")
            xbmcgui.Dialog().notification(
                "KDMM playback",
                message,
                xbmcgui.NOTIFICATION_ERROR, 8000)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return

        candidates = _filter_playable_candidates(
            fetch_result.get("candidates") or [],
            season=season if catalog_type == "series" else None,
            episode=episode if catalog_type == "series" else None,
            episode_title=title if catalog_type == "series" else None,
        )

        if not candidates:
            xbmcgui.Dialog().notification(
                "KDMM",
                "No playable streams",
                xbmcgui.NOTIFICATION_ERROR, 8000)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return

    # ---- 3. Ensure candidates is a list ----------------------------- #
    candidates = _filter_playable_candidates(
        candidates,
        season=season if catalog_type == "series" else None,
        episode=episode if catalog_type == "series" else None,
        episode_title=title if catalog_type == "series" else None,
    )

    # ---- 4. Store selected candidate for service.py cleanup ---------- #
    chosen_idx = 0
    for i, c in enumerate(candidates):
        if (not _candidate_needs_accessibility_check(c)
                or is_stream_accessible(c["url"], c.get("headers") or {})):
            if i > 0:
                _log(f"Skipped {i} inaccessible candidate(s); using: {c['name']!r}")
            chosen_idx = i
            break
        _log(f"Candidate {i} ({c['name']!r}) is too small – skipping", xbmc.LOGWARNING)
    else:
        _log("All candidates failed size check – falling back to first", xbmc.LOGWARNING)
        chosen_idx = 0

    stream = candidates[chosen_idx]
    # Every resolved AllDebrid candidate holds a magnet. Release all but the
    # one about to play (and any that share its magnet, as a season pack does).
    chosen_key = _provider_state_key(stream)
    _cleanup_candidates([
        candidate for index, candidate in enumerate(candidates)
        if index != chosen_idx
        and (chosen_key is None or _provider_state_key(candidate) != chosen_key)
    ])

    remaining = [stream]
    playback_label = _playback_label(title, showtitle, season, episode, year)
    stream_cache.set(media_id, remaining, label=playback_label)
    _log(f"Stored selected candidate for {media_id}: {stream['name']!r}")
    try:
        LastPlayedSource(_USERDATA_PATH).set(
            media_id, stream, label=playback_label,
        )
    except Exception as exc:
        _log(f"Could not record the last played source: {exc}", xbmc.LOGWARNING)
    WIN.setProperty(PROP_CANDIDATES, json.dumps(remaining))

    # ---- 5. Play first remaining candidate -------------------------- #
    _play_stream(
        media_id=media_id,
        url=stream["url"],
        headers_dict=stream.get("headers") or {},
        imdb=imdb,
        tmdb=tmdb,
        title=title,
        showtitle=showtitle,
        season=season,
        episode=episode,
        year=year,
        no_resume=NO_RESUME,
    )


def action_clear_cache(params):
    """Clear the stream cache for one item (or all items)."""
    imdb = params.get("imdb", "").strip()
    season = params.get("season", "").strip()
    episode = params.get("episode", "").strip()

    if imdb and season and episode:
        media_id = f"{imdb}:{season}:{episode}"
    elif imdb:
        media_id = imdb
    else:
        media_id = None

    StreamCache(_USERDATA_PATH).clear(media_id)
    if imdb and season:
        PackBindingCache(_USERDATA_PATH).clear(imdb, season)
    elif imdb:
        PackBindingCache(_USERDATA_PATH).clear(imdb)
    else:
        PackBindingCache(_USERDATA_PATH).clear()
    label = media_id if media_id else "all entries"
    xbmcgui.Dialog().notification(
        "KDMM",
        f"Stream cache cleared ({label})",
        xbmcgui.NOTIFICATION_INFO,
    )


def action_block_last_source(params):
    """Block the source behind the last play so the next play picks another."""
    last_played = LastPlayedSource(_USERDATA_PATH)
    last = last_played.get()
    if not last:
        xbmcgui.Dialog().ok(
            "KDMM",
            "There is no last played source to block. Play something first.",
        )
        return

    torrent_hash = last["hash"]
    blocked = UserBlockedSourceCache(_USERDATA_PATH)
    release = last.get("release") or last.get("file") or torrent_hash[:8]
    if blocked.is_blocked(torrent_hash):
        xbmcgui.Dialog().ok("KDMM", f"This source is already blocked:[CR]{release}")
        return

    lines = []
    if last.get("label"):
        lines.append(f"Last played: {last['label']}")
    lines.append(f"Source: {release}")
    lines.append("KDMM will pick a different source the next time you play it.")
    if not xbmcgui.Dialog().yesno(
        "KDMM - Block last played source",
        "[CR]".join(lines),
        yeslabel="Block",
        nolabel="Cancel",
    ):
        return

    blocked.block(
        torrent_hash, name=release,
        media_id=last.get("media_id", ""), label=last.get("label", ""),
    )
    # Forget everything that points at this torrent (a season pack can back
    # many episodes) so the next play does a fresh lookup without it.
    StreamCache(_USERDATA_PATH).clear_hash(torrent_hash)
    PackBindingCache(_USERDATA_PATH).clear_hash(torrent_hash)
    _log(f"User blocked source {torrent_hash[:8]} ({release!r})")
    xbmcgui.Dialog().notification(
        "KDMM", "Source blocked", xbmcgui.NOTIFICATION_INFO,
    )


def _pick_entries(heading, entries, describe):
    """Multi-select from a newest-first list; return the chosen entries."""
    picked = xbmcgui.Dialog().multiselect(heading, [describe(e) for e in entries])
    return [entries[i] for i in picked or []]


def action_manage_cache(params):
    """List cached streams and clear only the ones the user ticks."""
    stream_cache = StreamCache(_USERDATA_PATH)
    entries = stream_cache.entries()
    if not entries:
        xbmcgui.Dialog().notification(
            "KDMM", "Stream cache is empty", xbmcgui.NOTIFICATION_INFO,
        )
        return

    def describe(entry):
        name = entry["label"] or entry["media_id"]
        return f"{name}  -  {entry['file']}" if entry["file"] else name

    chosen = _pick_entries(
        "KDMM - Clear cached streams (newest first)", entries, describe,
    )
    if not chosen:
        return
    stream_cache.clear_many([entry["media_id"] for entry in chosen])
    pack_cache = PackBindingCache(_USERDATA_PATH)
    for entry in chosen:
        # Same as clearing one item: an episode also forgets its season's
        # bound pack so the next play does a full lookup.
        parts = entry["media_id"].split(":")
        if len(parts) >= 2:
            pack_cache.clear(parts[0], parts[1])
    count = len(chosen)
    xbmcgui.Dialog().notification(
        "KDMM",
        f"Cleared {count} cached stream{'' if count == 1 else 's'}",
        xbmcgui.NOTIFICATION_INFO,
    )


def action_manage_blocked(params):
    """List blocked sources and unblock only the ones the user ticks."""
    blocked = UserBlockedSourceCache(_USERDATA_PATH)
    entries = blocked.entries()
    if not entries:
        xbmcgui.Dialog().notification(
            "KDMM", "No blocked sources", xbmcgui.NOTIFICATION_INFO,
        )
        return

    def describe(entry):
        release = entry["name"] or entry["hash"][:8]
        name = entry["label"] or entry["media_id"]
        return f"{name}  -  {release}" if name else release

    chosen = _pick_entries(
        "KDMM - Unblock sources (newest first)", entries, describe,
    )
    if not chosen:
        return
    count = blocked.unblock_many([entry["hash"] for entry in chosen])
    xbmcgui.Dialog().notification(
        "KDMM",
        f"Unblocked {count} source{'' if count == 1 else 's'}",
        xbmcgui.NOTIFICATION_INFO,
    )


def action_unblock_sources(params):
    """Forget every source the user blocked."""
    blocked = UserBlockedSourceCache(_USERDATA_PATH)
    count = len(blocked)
    if not count:
        xbmcgui.Dialog().notification(
            "KDMM", "No blocked sources", xbmcgui.NOTIFICATION_INFO,
        )
        return
    noun = "source" if count == 1 else "sources"
    if not xbmcgui.Dialog().yesno(
        "KDMM - Unblock sources",
        f"Unblock {count} blocked {noun}?",
        yeslabel="Unblock",
        nolabel="Cancel",
    ):
        return
    blocked.clear()
    xbmcgui.Dialog().notification(
        "KDMM", f"Unblocked {count} {noun}", xbmcgui.NOTIFICATION_INFO,
    )


def action_clear_progress(params):
    """Reset the locally-stored resume position for one item."""
    imdb = params.get("imdb", "").strip()
    season = params.get("season", "").strip()
    episode = params.get("episode", "").strip()

    if imdb and season and episode:
        media_id = f"{imdb}:{season}:{episode}"
    elif imdb:
        media_id = imdb
    else:
        xbmcgui.Dialog().notification(
            "KDMM", "Provide imdb param to clear progress",
            xbmcgui.NOTIFICATION_WARNING,
        )
        return

    pc = ProgressCache(_USERDATA_PATH)
    pc.set_progress(media_id, 0.0, watched=False)
    xbmcgui.Dialog().notification(
        "KDMM",
        f"Resume position cleared for {media_id}",
        xbmcgui.NOTIFICATION_INFO,
    )


# ------------------------------------------------------------------ #
# Router
# ------------------------------------------------------------------ #

def action_main_menu():
    """
    Show a simple main menu when the addon is launched directly.
    """
    items = [
        ("Clear Stream Cache",
         "Force re-fetch stream URLs on next play",
         "plugin://plugin.video.kdmm/?action=clear_cache"),
        ("Manage Cached Streams",
         "Pick which cached streams to clear",
         "plugin://plugin.video.kdmm/?action=manage_cache"),
        ("Block Last Played Source",
         "Stop using the source that just played and pick another next time",
         "plugin://plugin.video.kdmm/?action=block_last_source"),
        ("Manage Blocked Sources",
         "Pick which blocked sources to unblock",
         "plugin://plugin.video.kdmm/?action=manage_blocked"),
        ("Unblock All Sources",
         "Allow every source you blocked again",
         "plugin://plugin.video.kdmm/?action=unblock_sources"),
    ]

    listing = []
    for label, label2, url in items:
        li = xbmcgui.ListItem(label=label, label2=label2)
        li.setProperty("IsPlayable", "false")
        listing.append((url, li, False))

    xbmcplugin.setContent(ADDON_HANDLE, "files")
    xbmcplugin.addDirectoryItems(ADDON_HANDLE, listing, len(listing))
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def action_set_default_player(params):
    """Make KDMM the helper's default player, replacing any other choice."""
    from default_player import set_default_player
    if set_default_player(force=True) is None:
        xbmcgui.Dialog().notification("KDMM", "TMDb Bingie Helper is not installed",
                                      xbmcgui.NOTIFICATION_WARNING)
        return
    xbmcgui.Dialog().notification("KDMM", "KDMM is the default player for movies and episodes",
                                  xbmcgui.NOTIFICATION_INFO)


def addon_router():
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action", "")

    if action in ("play_movie", "play_episode", "play"):
        action_play(params)
    elif action == "authorize_rd":
        rd_authorize()
    elif action == "revoke_rd":
        rd_revoke()
        xbmcgui.Dialog().notification("KDMM", "Real-Debrid authorization revoked",
                                       xbmcgui.NOTIFICATION_INFO)
    elif action == "authorize_ad":
        ad_authorize()
    elif action == "revoke_ad":
        ad_revoke()
        xbmcgui.Dialog().notification("KDMM", "AllDebrid authorization revoked",
                                      xbmcgui.NOTIFICATION_INFO)
    elif action == "clear_cache":
        action_clear_cache(params)
    elif action == "block_last_source":
        action_block_last_source(params)
    elif action == "manage_cache":
        action_manage_cache(params)
    elif action == "manage_blocked":
        action_manage_blocked(params)
    elif action == "unblock_sources":
        action_unblock_sources(params)
    elif action == "clear_progress":
        action_clear_progress(params)
    elif action == "set_default_player":
        action_set_default_player(params)
    else:
        action_main_menu()


if __name__ == "__main__":
    addon_router()
